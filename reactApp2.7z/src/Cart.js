import React from 'react';
import {
    Card, CardImg, CardBody,
    CardTitle, CardSubtitle, CardText, Button
} from 'reactstrap';


const Cart = (props) => {
    return props.dataList.map((item, i) => {
        return (
            <div class="col-3">
                cart items here
            </div>
        );
    });
};
export default Cart;
